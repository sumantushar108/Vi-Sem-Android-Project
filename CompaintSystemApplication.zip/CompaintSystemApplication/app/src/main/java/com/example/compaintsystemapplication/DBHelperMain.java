package com.example.compaintsystemapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.*;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelperMain extends SQLiteOpenHelper {

    public static final String DBNAME = "complaint.db";

    public DBHelperMain(Context context) {
        super(context,"complaint.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE login(Type text, Fname VARCHAR(50), Lname VARCHAR(30), FatherName VARCHAR(60), MotherName VARCHAR(60), DoB INT(10), Address VARCHAR(2000), IncPlace VARCHAR(200), FileAg VARCHAR(100), Lawbr VARCHAR(30), Incidence MEDIUMTEXT(20000))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE if exists complaint");
    }

    public Boolean insertData(String Type, String Fname, String Lname, String FatherName, String MotherName, int dob, String Address, String IncPlace, String VictimName, String FileAg, String Lawbr, String Incidence)
    {

        int i=0;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Type",Type);
        cv.put("Fname",Fname);
        cv.put("Lname",Lname);
        cv.put("FatherName",FatherName);
        cv.put("MotherName",MotherName);
        cv.put("dob",dob);
        cv.put("Address",Address);
        cv.put("IncPlace",IncPlace);
        cv.put("Victim Name",VictimName);
        cv.put("FileAg",FileAg);
        cv.put("Lawbr",Lawbr);
        cv.put("Incidence",Incidence);

        long result = db.insert("complaint",null,cv);
        if(result==-1)
            return false;
        else
            return true;
    }
}
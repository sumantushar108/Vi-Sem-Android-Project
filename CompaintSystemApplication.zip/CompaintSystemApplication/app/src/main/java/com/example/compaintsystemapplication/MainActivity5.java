package com.example.compaintsystemapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity5 extends AppCompatActivity {

    DBHelperMain db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        EditText txt = (EditText) findViewById(R.id.txt);
        TextView disptxt = (TextView) findViewById(R.id.disptxt);
        Button btnn = (Button) findViewById(R.id.button);
        ImageButton btn = (ImageButton) findViewById(R.id.imgbtn);
        db = new DBHelperMain(this);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity5.this, MainActivity3.class);
                startActivity(intent);
            }
        });

        btnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                disptxt.setText("Complaint is in Progress !!!!");

            }
        });

    }
}
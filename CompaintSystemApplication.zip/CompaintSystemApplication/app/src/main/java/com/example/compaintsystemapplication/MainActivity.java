package com.example.compaintsystemapplication;

//import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
//import android.graphics.RenderEffect;
//import android.graphics.Shader;
//import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.*;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    EditText Username, Password;
    Button btn;
    DBHelperLogin db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = (EditText) findViewById(R.id.txt1);
        Password = (EditText) findViewById(R.id.txt2);

        TextView txt = (TextView) findViewById(R.id.txt);

        btn = (Button) findViewById(R.id.button1);

        db = new DBHelperLogin(this);
        //if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        //    img.setRenderEffect(RenderEffect.createBlurEffect(50,50,Shader.TileMode.MIRROR));

        String text = "Not Registered Yet!     Register Now";

        SpannableString ss =new SpannableString(text);
        ClickableSpan click1 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        };

        ss.setSpan(click1,24,36, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        txt.setText(ss);
        txt.setMovementMethod(LinkMovementMethod.getInstance());

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userStr = Username.getText().toString();
                String passwdStr = Password.getText().toString();

                if(userStr.equals("") || passwdStr.equals("")) {
                    Toast.makeText(MainActivity.this, "Missing Detail!!... Enter Details Properly", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Boolean checklogin = db.checkPassword(userStr, passwdStr);
                    if(checklogin==true) {
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
package com.example.compaintsystemapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.Calendar;
import java.util.Random;

public class MainActivity4 extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
        String[] complaintType = { " " ,"Fraud Call/Threats", "Stalking/CyberBullying/BlackMail", "Theft/Robbery",  "Kidnapping/Ransom", "Female Attack/Unusual Activities", "Unusual Media Content", "Fake Identity/Profile", "Violence in Local/Assault", "Domestic Violence", "Dowry", "Hacking/Ransomewares", "Trafficking", "Reporting Application related Issues", "Reporting Social Issue", "Other"};
        String[] lawbr = {" ", "Individual", "Organization", "Group/Gang"};
        Button btnn;
        EditText Fname,Lname,FatherName,MotherName,dob,Address,IncPlace,VictimName,FileAg,Incidence;
        DBHelperMain db;

        DatePickerDialog datepk;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main4);

//            Random random = new Random();
//            long double randomNumber = random.nextDouble(9999999999999–100000000000);

            ImageButton btn = (ImageButton) findViewById(R.id.imgbtn);
            btnn = (Button) findViewById(R.id.btn);
            Fname = (EditText) findViewById(R.id.txt2);
            Lname = (EditText) findViewById(R.id.txt3);
            FatherName = (EditText) findViewById(R.id.txt4);
            MotherName = (EditText) findViewById(R.id.txt5);
            dob = (EditText) findViewById(R.id.txt6);
            Address = (EditText) findViewById(R.id.txt7);
            IncPlace = (EditText) findViewById(R.id.txt8);
            VictimName = (EditText) findViewById(R.id.txt9);
            FileAg = (EditText) findViewById(R.id.txt10);
            Incidence = (EditText) findViewById(R.id.txt12);

            db = new DBHelperMain(this);

            Spinner Type = findViewById(R.id.spinner1);
            Type.setOnItemSelectedListener(this);

            ArrayAdapter ad1 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,complaintType);
            ad1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            Type.setAdapter(ad1);

            Spinner Lawbr = findViewById(R.id.spinner2);
            Lawbr.setOnItemSelectedListener(this);

            ArrayAdapter ad2 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,lawbr);
            ad2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            Lawbr.setAdapter(ad2);

            dob.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final Calendar c = Calendar.getInstance();
                    int mYear = c.get(Calendar.YEAR); // current year
                    int mMonth = c.get(Calendar.MONTH); // current month
                    int mDay = c.get(Calendar.DAY_OF_MONTH); // current day

                    datepk = new DatePickerDialog(MainActivity4.this,
                            new DatePickerDialog.OnDateSetListener() {

                                @Override
                                public void onDateSet(DatePicker view, int year,
                                                      int monthOfYear, int dayOfMonth) {
                                    // set day of month , month and year value in the edit text
                                    dob.setText(dayOfMonth + "/"
                                            + (monthOfYear + 1) + "/" + year);

                                }
                            }, mYear, mMonth, mDay);
                    datepk.show();
                }
            });

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity4.this, MainActivity3.class);
                    startActivity(intent);
                }
            });

            btnn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Type1 = Type.getSelectedView().toString();
                    String Fname1 = Fname.getText().toString();
                    String Lname1 = Lname.getText().toString();
                    String FatherName1 = FatherName.getText().toString();
                    String MotherName1 = MotherName.getText().toString();
                    String dob1 = dob.getText().toString();
                    String Address1 = Address.getText().toString();
                    String IncPlace1 = IncPlace.getText().toString();
                    String VictimName1 = VictimName.getText().toString();
                    String FileAg1 = FileAg.getText().toString();
                    String Lawbr1 = Lawbr.getSelectedView().toString();
                    String Incidence1 = Incidence.getText().toString();

                    if(Type1.equals("")||Fname1.equals("")||Lname1.equals("")||FatherName1.equals("")||MotherName1.equals("")||dob1.equals("")||Address1.equals("")||IncPlace1.equals("")||VictimName1.equals("")||FileAg1.equals("")||Lawbr1.equals("")||Incidence1.equals(""))
                        Toast.makeText(MainActivity4.this,"Missing Detail!!... Enter Details Properly", Toast.LENGTH_SHORT).show();
                    else
                    {
                        Boolean insert = db.insertData(Type1,Fname1,Lname1,FatherName1,MotherName1, Integer.parseInt(dob1),Address1,IncPlace1,VictimName1,FileAg1,Lawbr1,Incidence1);
                        if (insert == true) {
                                Toast.makeText(MainActivity4.this, "Complaint Registered Successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity4.this, MainActivity3.class);
                                startActivity(intent);
                        }
                        else
                            Toast.makeText(MainActivity4.this, "Something Went Wrong... Try Again", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            //Toast.makeText(getApplicationContext(), complaintType[position],Toast.LENGTH_LONG).show();
            //Toast.makeText(getApplicationContext(), lawbr[position],Toast.LENGTH_LONG).show();

        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }

}
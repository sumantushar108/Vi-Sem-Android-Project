package com.example.compaintsystemapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.*;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelperLogin extends SQLiteOpenHelper {

    public static final String DBNAME = "Login.db";

    public DBHelperLogin(Context context) {
        super(context,"Login.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE login(Name VARCAHR(50), Email VARCHAR(70), Username VARCHAR(30), Password VARCHAR(30))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE if exists login");
    }

    public Boolean insertData(String Name, String Email, String Username, String Password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",Name);
        cv.put("Email",Email);
        cv.put("Username",Username);
        cv.put("Password",Password);

        long result = db.insert("login",null,cv);
        if(result==-1)
            return false;
        else
            return true;
    }

    public Boolean checkUsername(String Username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM login WHERE Username = ?",new String[]{Username});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkPassword(String Username, String Password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM login WHERE Username = ? AND Password = ?",new String[]{Username,Password});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }
}

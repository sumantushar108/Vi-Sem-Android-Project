package com.example.compaintsystemapplication;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.sql.*;
public class MainActivity2 extends AppCompatActivity {
    EditText name,email,username,password;
    Button btn;
    DBHelperLogin db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        name = (EditText) findViewById(R.id.txt1);
        email = (EditText) findViewById(R.id.txt2);
        username = (EditText) findViewById(R.id.txt3);
        password = (EditText) findViewById(R.id.txt4);

        db = new DBHelperLogin(this);

        ImageButton imgbtnn = (ImageButton) findViewById(R.id.imgbtn);

        imgbtnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btn = (Button) findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name = name.getText().toString();
                String Email = email.getText().toString();
                String Username = username.getText().toString();
                String Password = password.getText().toString();

                if(Name.equals("")||Email.equals("")||Username.equals("")||Password.equals(""))
                    Toast.makeText(MainActivity2.this,"Missing Detail!!... Enter Details Properly", Toast.LENGTH_SHORT).show();
                else
                {
                    Boolean checkuser = db.checkUsername(Username);
                    if(checkuser==false) {
                        Boolean insert = db.insertData(Name, Email, Username, Password);
                        if (insert == true) {
                            Toast.makeText(MainActivity2.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                            startActivity(intent);
                        }
                        else
                            Toast.makeText(MainActivity2.this, "Something Went Wrong... Try Again", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(MainActivity2.this, "User already Registered.. Go to Login Page to Login", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}